<?php

return [
  /*
    |--------------------------------------------------------------------------
    | Event Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used for announcement screen.
    |
    */

  // This part is used for validation purpose
  'userName' => [
    'required' => 'Please Enter the Username',
    'string' => 'Username Must be a String',
    'max' => 'Only 255 Characters allowed',
  ],
  'email' => [
    'required' => 'Please Enter your Email ID',
    'string' => 'Email Must be a String',
    'min' => 'Mininimum 6 Characters Required',
    'max' => 'Only 255 Characters allowed',

  ],
  'userUID' => [
    'required' => 'Please Enter UserUID',
  ], 
  'eventid' => [
    'required' => 'Please Enter Eventid',
    'int'   => 'Event Id should be a number',
  ], 
  // Response
  'UserNotFound' => 'User Not Found',
  'eventlist_success' => 'Event Category Listed',
  'success' => 'Success',
  'pass_missmatch' => 'Password Mismatch'
  



 
];
